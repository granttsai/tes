var viewerPath = "C:\\WINDOWS\\explorer.exe";
var shell = new ActiveXObject("WScript.Shell");
shell.Run('"' + viewerPath + '" "' + FolderView.Path+ '"', 1, false);